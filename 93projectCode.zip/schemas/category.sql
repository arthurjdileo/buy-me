CREATE TABLE Category (
	id int NOT NULL AUTO_INCREMENT,
	name varchar(75) NOT NULL,
	PRIMARY KEY (id)
);
 //<!-- Initialize the plugin -->
$('#exampleSlider').multislider();

 //<!-- Initialize with options, if needed -->
$('#exampleSlider').multislider({
  interval: 10000,
  slideAll: false
});



$('#categoriesSlider').multislider();

 //<!-- Initialize with options, if needed -->
$('#categoriesSlider').multislider({
	interval: 1000,
	slideAll: false,
});

$('#similarSlider').multislider();

 //<!-- Initialize with options, if needed -->
$('#similarSlider').multislider({
	interval: 10000,
	slideAll: false,
});

$('#otherSlider').multislider();

 //<!-- Initialize with options, if needed -->
$('#otherSlider').multislider({
	interval: 10000,
	slideAll: false,
});